PAINTBALL MARKER – Minecraft Java 1.20.1

Zawartość:
- gotowy resource pack z modelem 3D i pikselową teksturą,
- model JSON do importu/edycji w Blockbench,
- tekstura PNG 128x128.

INSTALACJA (resource pack):
1. Rozpakuj ZIP do folderu .minecraft/resourcepacks (albo skopiuj ZIP bez rozpakowywania).
2. Włącz paczkę w Opcje -> Paczki zasobów.
3. W świecie użyj komendy:
   /give @p minecraft:carrot_on_a_stick{CustomModelData:1001}
4. Otrzymany przedmiot wyświetli marker paintballowy.

MODEL I TEKSTURA:
- Model: assets/paintball/models/item/paintball_marker.json
- Tekstura: assets/paintball/textures/item/paintball_marker.png
- Model JSON jest w formacie Minecraft Java Item Model i można go zaimportować do Blockbench.

Uwagi:
- Paczka jest przygotowana dla Minecraft Java 1.20.1 (pack_format 15).
- To wersja resource pack, działa bez Forge/Fabric, ale wykorzystuje marchewkę na patyku jako bazowy przedmiot.
- Jeżeli chcesz podpiąć model pod własny przedmiot moda Forge/Fabric, wykorzystaj JSON i PNG z namespace paintball.
